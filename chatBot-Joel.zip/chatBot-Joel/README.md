Primero se debe de entrenar ejecutando el codigo fuente de chatTraining.py el cual genera un archivo nEs.npz, el cual pesara unos 400 MB, que es la data entrenada

Luego ejecutar chatRun.py